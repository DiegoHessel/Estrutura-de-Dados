package org.example;

public interface Bonificavel {
    Double getValorBonus();
}
