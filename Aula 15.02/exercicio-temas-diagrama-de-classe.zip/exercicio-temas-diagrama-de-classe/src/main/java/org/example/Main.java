package org.example;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Mago mago = new Mago("Gandalf", "Magia", 100, 100, 100);
        int escolha;
        do {
            System.out.println("""
                    Escolha um personagem para Ser criado:
                    1 - Mago
                    2 - Inimigo
                    3 - Humano
                    4 - Heroi
                    5 - Sair
                    """);
            Scanner scanner = new Scanner(System.in);
            escolha = scanner.nextInt();
            switch (escolha) {
                case 1 -> {
                    Mago mago = new Mago("Gandalf", "Magia", 100, 100, 100);
                    System.out.println("-----------------------------------------------------------------------------");
                    System.out.println(mago);
                    mago.atacar();
                    mago.defender();
                    mago.lancarMagia();
                    System.out.println("-----------------------------------------------------------------------------");
                }
                case 2 -> {
                    Inimigo inimigo = new Inimigo("Orc", "Espada", 100);
                    System.out.println("-----------------------------------------------------------------------------");
                    System.out.println(inimigo);
                    inimigo.atacar();
                    System.out.println("-----------------------------------------------------------------------------");
                }
                case 3 -> {
                    Humano humano = new Humano("Aragorn", "Espada", 100, 100, 100);
                    System.out.println("-----------------------------------------------------------------------------");
                    System.out.println(humano);
                    humano.atacar();
                    humano.defender();
                    humano.usarArma();
                    System.out.println("-----------------------------------------------------------------------------");
                }
                case 4 -> {
                Heroi heroi = new Humano("Aragorn", "Espada", 100, 100, 100);
                    System.out.println(heroi);
                    heroi.atacar();
                    heroi.defender();
                }
                case 5 -> System.exit(0);
            }
        } while (escolha != 5);
    }
}