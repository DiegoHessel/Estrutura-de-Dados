package org.example;

public abstract class Heroi implements Lutador{
    private String nome;
    private String poder;
    int vida;

    public Heroi() {
    }

    public Heroi(String nome, String poder, int vida) {
        this.nome = nome;
        this.poder = poder;
        this.vida = vida;
    }
    public void atacar(){
        System.out.println(nome +" esta atacando com "+poder);
    }

    public void getNome() {
        this.nome = nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getPoder() {
        return poder;
    }

    public void setPoder(String poder) {
        this.poder = poder;
    }

    public int getVida() {
        return vida;
    }

    public void setVida(int vida) {
        this.vida = vida;
    }

    @Override
    public String toString() {
        return "Heroi{" +
                "nome='" + nome + '\'' +
                ", poder='" + poder + '\'' +
                ", vida=" + vida +
                '}';
    }
}
