package org.example;

public interface Lutador {
    void atacar();
    void defender();
}
